from kyt import *
from telethon import events, Button
import subprocess

@bot.on(events.NewMessage(pattern=r"(?:.menu|/menu)$"))
@bot.on(events.CallbackQuery(data=b'menu'))
async def menu(event):
    sender = await event.get_sender()
    if valid(str(sender.id)) != "true":
        try:
            await event.answer("🚫 Akses Ditolak!", alert=True)
        except:
            await event.reply("🚫 Akses Ditolak!")
        return

    def get_count(file_path):
        cmd = f"grep -c '^### ' {file_path}"
        try:
            return int(subprocess.check_output(cmd, shell=True).decode().strip())
        except:
            return 0

    # Hitung jumlah akun dari masing-masing file
    ssh = get_count("/etc/ssh/.ssh.db")
    vmess = get_count("/etc/xray/vmess/config.json")
    vless = get_count("/etc/xray/vless/config.json")
    trojan = get_count("/etc/xray/trojan/config.json")
    ss = get_count("/etc/xray/shadowsocks/config.json")

    # Informasi sistem
    try:
        namaos = subprocess.check_output("grep -w PRETTY_NAME /etc/os-release | head -n1 | sed 's/.*=//g' | tr -d '\"'", shell=True).decode().strip()
        ipsaya = subprocess.check_output("curl -s ipv4.icanhazip.com", shell=True).decode().strip()
        city = subprocess.check_output("cat /etc/xray/city", shell=True).decode().strip()
    except:
        namaos, ipsaya, city = "Unknown", "Unknown", "Unknown"

    msg = f"""
╭━━━━━━━━━━━━━━━━━━━━━━━━━╮
┃        ⚡ 𝗔𝗗𝗠𝗜𝗡 𝗣𝗔𝗡𝗘𝗟 ⚡
╰━━━━━━━━━━━━━━━━━━━━━━━━━╯
📌 **System Info:**
• OS         : `{namaos}`
• City       : `{city}`
• IP VPS     : `{ipsaya}`
• Domain     : `{DOMAIN}`

📊 **Account Statistics:**
• 🟢 SSH OVPN     : `{ssh}` akun
• 🔵 XRAY VMESS   : `{vmess}` akun
• 🟣 XRAY VLESS   : `{vless}` akun
• 🔴 XRAY TROJAN  : `{trojan}` akun
• 🟠 SHADOWSOCKS  : `{ss}` akun

📁 **Silakan pilih menu layanan di bawah ini:**
"""

    inline = [
        [Button.inline("🟢 SSH OVPN", b"ssh")],
        [Button.inline("🔵 VMESS", b"vmess"), Button.inline("🟣 VLESS", b"vless")],
        [Button.inline("🔴 TROJAN", b"trojan"), Button.inline("🟠 SHADOW", b"shadowsocks")],
        [Button.inline("ℹ️ VPS INFO", b"info"), Button.inline("⚙️ SETTINGS", b"setting")],
        [Button.inline("🔙 Back to Start", b"start")]
    ]

    try:
        await event.edit(msg, buttons=inline)
    except:
        await event.reply(msg, buttons=inline)